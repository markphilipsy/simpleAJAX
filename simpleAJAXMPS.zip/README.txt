To start using this:
files:
connect.php = for connecting to our server and database
index.php = the home where we are going to test it
itsession.sql = the sample database
loader1.gif = for displaying our loader
seaerchcontent.php = the file that we call to load the values that we want

create a database named itsession (look at the connect.php)
import the .sql
make sure to have your database and table ready
open the index.php


(c)Mark Philip M. Sy