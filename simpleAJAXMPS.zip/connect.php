<?php
/*
this script is for connecting the actual system to the database.
the configurations can be changed here
*/
$mysql_host = 'localhost';
$mysql_user = 'root';
$mysql_pass = '';

$mysql_db = 'itsession';//lastname_theodbs
	
if(!mysql_connect($mysql_host, $mysql_user, $mysql_pass ) ||!mysql_select_db($mysql_db)){
	die("Error1: " . mysql_error());
	}
	
?>