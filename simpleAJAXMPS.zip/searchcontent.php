<?php
//include("connect.php");
//to make sure the search is a bit more pleasing to the eyes,use connectv2.php
include("connect.php");
//add if isset
$st_id = $_GET['id'];

	$query = "select * from stories where st_id = $st_id ";
//	echo $query;
	$result = mysql_query($query)or die ("error:".mysql_error());
	
	
	while($row=mysql_fetch_array($result))
	{
		echo $row['st_content'];
	}
	
	if(mysql_num_rows($result)==0)
	echo "No record found";
	
?>