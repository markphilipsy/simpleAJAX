-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2016 at 11:23 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `itsession`
--

-- --------------------------------------------------------

--
-- Table structure for table `stories`
--

CREATE TABLE IF NOT EXISTS `stories` (
  `st_id` int(11) NOT NULL AUTO_INCREMENT,
  `st_name` text NOT NULL,
  `st_content` text NOT NULL,
  PRIMARY KEY (`st_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `stories`
--

INSERT INTO `stories` (`st_id`, `st_name`, `st_content`) VALUES
(1, 'The Ant and the Grasshopper', 'The Ant and the Grasshopper, alternatively titled The Grasshopper and the Ant (or Ants), is one of Aesops Fables, numbered 373 in the Perry Index.[1] The fable describes how a hungry grasshopper begs for food from an ant when winter comes and is refused. The situation sums up moral lessons about the virtues of hard work and planning for the future.[2]'),
(2, 'The Ape and the Fox', 'The Ape and the Fox is one of Aesops Fables and is numbered 81 in the Perry Index'),
(3, 'The Dog and the Wolf', 'The Dog and the Wolf is one of Aesops Fables, numbered 346 in the Perry Index.[1] It has been popular since antiquity as an object lesson of how freedom should not be exchanged for comfort or financial gain. An alternative fable with the same moral concerning different animals is less well known.');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
