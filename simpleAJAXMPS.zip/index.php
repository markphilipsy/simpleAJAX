<?php
include_once("connect.php");
?>

<html>
<head>
<style>
#content1
{
	resize:none;
	width:50em;
	height:10em;

}
#content2{
	width:50%;
}
#loader{
	display:none;
}
</style>
<script>

	function loadContent(stid)
	{
		var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
	  	//this will set the loader to display and to clear any values on our target
	  	document.getElementById('loader').style.display='block';
	  	document.getElementById('content2').innerHTML = "";
	    document.getElementById('content1').value = "";

	    if (xhttp.readyState == 4 && xhttp.status == 200) {//the response will be handled here
	      //the targets will be loaded with values
	      document.getElementById('content2').innerHTML = xhttp.responseText;//for the div
	      document.getElementById('content1').value = xhttp.responseText;//for the textarea
	      //the loader will disappear
	      document.getElementById('loader').style.display='none';
	    }
	  };
	  xhttp.open("GET", "searchcontent.php?id="+stid, true);//calling the file that will handle our request
	  xhttp.send();//sending the request
	}

</script>

</head>

<body>
	
<?php

	$sql = "select * from stories";//get all of the records
	$result = mysql_query($sql) or die ("error:".mysql_error());

	if(mysql_num_rows($result)>0)
	{
		while($row = mysql_fetch_array($result))
		{	//set all the links and button to handle the request of the user
						
			echo '<a onclick="loadContent('.$row[0].')">'.$row[0].' - '.$row[1].'</a><input type = "button" onclick="loadContent('.$row[0].')" value="Load this ('.$row[0].')"><br>';
		}


		echo'Description:
		<div id="loader"><img src="loader1.gif"  width="40"></div><br>';

		echo'<div id = "content2">insert it here</div><br>';

		echo'<textarea id = "content1">insert it here </textarea>';
	}
	else
	{
		echo 'No record found';
	}
?>
</body>
</html>